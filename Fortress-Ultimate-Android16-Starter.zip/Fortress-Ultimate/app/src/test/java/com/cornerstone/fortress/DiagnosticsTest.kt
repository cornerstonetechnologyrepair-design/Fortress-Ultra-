package com.cornerstone.fortress

import org.junit.Assert.*
import org.junit.Test

class DiagnosticsTest {
    @Test fun batteryPercentageHandlesMissingData() {
        assertNull(Diagnostics.batteryPercent(-1, 100))
        assertNull(Diagnostics.batteryPercent(50, 0))
        assertEquals(50, Diagnostics.batteryPercent(50, 100))
        assertEquals(100, Diagnostics.batteryPercent(110, 100))
    }
    @Test fun formatsStorage() { assertEquals("1.0 GiB", Diagnostics.formatGiB(1073741824)) }
}
