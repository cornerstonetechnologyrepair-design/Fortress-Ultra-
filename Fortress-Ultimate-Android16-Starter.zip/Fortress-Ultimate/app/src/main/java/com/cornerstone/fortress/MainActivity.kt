package com.cornerstone.fortress

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var panel: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 28, 32, 32) }
        scroll.addView(panel)
        setContentView(scroll)
        refresh()
    }
    private fun heading(text: String, size: Float = 19f) {
        panel.addView(TextView(this).apply { this.text = text; textSize = size; setTextColor(Color.rgb(17, 45, 79)); setPadding(0, 12, 0, 12) })
    }
    private fun action(label: String, onClick: () -> Unit) {
        panel.addView(Button(this).apply { text = label; setOnClickListener { onClick() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
    private fun refresh() {
        panel.removeAllViews()
        heading("FORTRESS ULTIMATE", 26f)
        heading("Local, read-only diagnostics • No root • No subscription", 14f)
        val readings = Diagnostics.collect(this)
        readings.forEach { heading("${it.name}: ${it.detail}", 16f) }
        val stamp = DateFormat.getDateTimeInstance().format(Date())
        getSharedPreferences("history", MODE_PRIVATE).edit().putString("last", "$stamp\n${readings.joinToString("\n") { "${it.name}: ${it.detail}" }}").apply()
        action("Refresh diagnostics") { refresh() }
        action("View last saved snapshot") {
            panel.removeAllViews()
            heading("Last saved snapshot")
            heading(getSharedPreferences("history", MODE_PRIVATE).getString("last", "No history") ?: "No history", 15f)
            action("Back") { refresh() }
        }
        action("Open security settings") { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        action("Open accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        action("Open application settings") { startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) }
        heading("Not included in this starter: VPN/firewall, antivirus scanning, backup, automatic alerts, camera/audio enhancement, and privileged hardware tuning.", 14f)
    }
}
