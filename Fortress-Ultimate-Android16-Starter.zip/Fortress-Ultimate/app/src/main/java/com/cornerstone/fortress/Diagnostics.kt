package com.cornerstone.fortress

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import java.text.DateFormat
import java.util.Date

/** Read-only diagnostics; no privileged settings or hardware controls. */
object Diagnostics {
    data class Reading(val name: String, val detail: String)

    fun collect(context: Context): List<Reading> {
        val result = mutableListOf<Reading>()
        result += Reading("Device", "${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = batteryPercent(level, scale)
        val temp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        result += Reading("Battery", "${pct?.let { "$it%" } ?: "Unknown"} • ${if (temp >= 0) "${temp / 10.0}°C" else "temperature unavailable"}")
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        result += Reading("Charging", when(status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
            else -> "Unknown"
        })
        val fs = StatFs(Environment.getDataDirectory().path)
        result += Reading("Internal storage", "${formatGiB(fs.availableBytes)} free of ${formatGiB(fs.totalBytes)}")
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        result += Reading("RAM", "${formatGiB(memory.availMem)} available of ${formatGiB(memory.totalMem)}")
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(network)
        val transport = when {
            caps == null -> "No active network"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Other network"
        }
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        result += Reading("Network", "$transport • ${if (validated) "internet validated" else "not validated"}")
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensorTypes = listOf(Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_LIGHT, Sensor.TYPE_PROXIMITY)
        val available = sensorTypes.count { sm.getDefaultSensor(it) != null }
        result += Reading("Sensors", "$available/${sensorTypes.size} common sensor types available")
        val accessibility = try { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) } catch (_: SecurityException) { null }
        result += Reading("Accessibility services", if (accessibility.isNullOrBlank()) "None reported enabled" else "Some services enabled; review Android Settings")
        result += Reading("Privacy", "Android permission manager is authoritative; other apps' private activity is restricted")
        return result
    }

    fun batteryPercent(level: Int, scale: Int): Int? = if (level < 0 || scale <= 0) null else (level * 100 / scale).coerceIn(0, 100)
    fun formatGiB(bytes: Long): String = "%.1f GiB".format(java.util.Locale.US, bytes.toDouble() / (1024 * 1024 * 1024))
}
