# Fortress Ultimate — Android 16 starter

**Status:** functional diagnostics starter, not the complete Fortress suite. No root or subscription.

## What works in source
- Battery level, charging state and temperature (battery broadcast)
- Internal storage and RAM summaries
- Active network transport and validation state
- Basic sensor availability
- Accessibility enabled-state indication (not a malware determination)
- Manual refresh, last-snapshot history, Android settings shortcuts

## Not implemented
VPN, packet filtering, DNS blocking, antivirus scanning, background notifications, automated backup, app inventory, Wi-Fi security auditing, SIM security, call/SMS interception, display/audio boosting, thermal throttling, firmware/BIOS changes. Android blocks many privileged controls for ordinary apps; VPN requires a single consented `VpnService` implementation. No claims of absolute security or improved signal strength.

## Build
Open in Android Studio with JDK 17 and Android SDK Platform 36, sync Gradle, then run `gradle :app:assembleDebug` (or use Android Studio's Build APK). CI installs Gradle 8.13. Gradle wrapper files are not included; generate with `gradle wrapper --gradle-version 8.13` if you have Gradle installed. GitHub Actions workflow builds on push.

## Architecture roadmap
1. Shared typed diagnostics interface and retention-limited local event store.
2. Single user-consented VPN service for firewall and DNS filtering (one VPN at a time).
3. Background work using WorkManager, notification permission, and battery-aware scheduling.
4. App inventory only with narrowly scoped package visibility and user consent.
5. Backup via Storage Access Framework; no unrestricted access to other apps' private data.
6. Device tests on Samsung SM-S176V Android 16; confirm hardware-specific APIs at runtime.

## Security
No `QUERY_ALL_PACKAGES`, SMS, call log, location, accessibility service, device admin, or root permission. No analytics, remote backend, subscriptions, or dangerous auto-cleaning. Device information is kept locally in app preferences.
